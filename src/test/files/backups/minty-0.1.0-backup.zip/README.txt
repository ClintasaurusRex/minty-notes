Minty Notes full workspace backup
Created: 2026-11-13T14:11:52.055Z

Restore it from Minty Notes → Settings → Restore. records.json holds notes, notebooks,
sections, and page layout. attachments/ holds the original image files.
This is a complete working copy, not a redacted document for sharing.
