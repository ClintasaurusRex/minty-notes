Minty Notes full workspace backup
Created: 2026-11-13T14:11:55.845Z

Restore it from Minty Notes → Settings → Restore. records.json holds projects, tasks, templates,
categories, tags, notes, notebooks, sections, links, and page layout. attachments/ holds the original image files.
This is a complete working copy, not a redacted document for sharing.
